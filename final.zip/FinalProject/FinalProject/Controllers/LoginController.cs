﻿using FinalProject.Models;
using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Controllers
{
    public class LoginController
    {
        #region Singleton
        private static LoginController instance;

        DBHelper db = new DBHelper();

        public static LoginController Instance
        {
            get
            {
                if (instance == null) instance = new LoginController();

                return instance;
            }
        }
        #endregion
        public void login()
        {


        }
    }
}
