﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Models
{
    public class PublishCompany
    {
        public string PublishID { get; set; }
        public string PublishName { get; set; }
        public string PublishAddress { get; set; }
        public string PublishPhone { get; set; }
        public string PublishEmail { get; set; }
    }
}
