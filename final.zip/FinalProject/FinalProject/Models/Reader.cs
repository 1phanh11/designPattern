﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject.Models
{
    public class Reader
    {
        public string ReaderID { get; set; }
        public string ReaderName { get; set; }
        public string ReaderGender { get; set; }
        public string ReaderAddress { get; set; }
        public string ReaderPhone { get; set; }
        public string ReaderEmail { get; set; }
        public string img { get; set; }
    }
}
